<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
  <div class="mb-4 rounded-2xl bg-white p-5 shadow">
    <div class="text-sm text-slate-500">Total Nilai Aset</div>
    <div class="mt-1 text-xl font-bold">Rp <?php echo e(number_format($totalValue,0,',','.')); ?></div>
  </div>

  <div class="rounded-2xl bg-white p-6 shadow">
    <form class="mb-4 flex flex-wrap gap-3">
      <select name="unit_usaha_id" class="rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm">
        <option value="">Semua Unit</option>
        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($u->id); ?>" <?php if((string)$u->id===request('unit_usaha_id')): echo 'selected'; endif; ?>><?php echo e($u->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

      <button class="rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white">Filter</button>
      <a href="<?php echo e(route('assets.index')); ?>" class="rounded-xl border px-4 py-2 text-sm">Reset</a>

      <a href="<?php echo e(route('assets.create')); ?>" class="ml-auto rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:opacity-90">
        + Tambah Aset
      </a>
    </form>

    <div class="overflow-auto">
      <table class="w-full text-sm">
        <thead>
          <tr class="border-b bg-slate-50 text-left">
            <th class="p-2">Nama</th>
            <th class="p-2">Unit</th>
            <th class="p-2">Tgl Perolehan</th>
            <th class="p-2 text-right">Harga</th>
            <th class="p-2 text-right">Qty</th>
            <th class="p-2 text-right">Total</th>
            <th class="p-2">Kondisi</th>
            <th class="p-2">Aksi</th>
          </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="border-b">
            <td class="p-2"><?php echo e($r->name); ?></td>
            <td class="p-2"><?php echo e($r->unitUsaha?->name ?? '-'); ?></td>
            <td class="p-2"><?php echo e($r->acquired_date?->format('d/m/Y') ?? '-'); ?></td>
            <td class="p-2 text-right">Rp <?php echo e(number_format($r->unit_cost,0,',','.')); ?></td>
            <td class="p-2 text-right"><?php echo e($r->qty); ?></td>
            <td class="p-2 text-right">Rp <?php echo e(number_format($r->total_value,0,',','.')); ?></td>
            <td class="p-2"><?php echo e($r->condition ?? '-'); ?></td>
           <td class="p-2">
  <div class="flex gap-2">
    <a class="text-indigo-700 underline" href="<?php echo e(route('assets.edit', $r->id)); ?>">Edit</a>

    <?php if(auth()->user()->role === 'superadmin'): ?>
      <form method="POST" action="<?php echo e(route('assets.destroy', $r->id)); ?>"
            onsubmit="return confirm('Hapus aset ini?');">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button class="text-rose-700 underline" type="submit">Hapus</button>
      </form>
    <?php endif; ?>
  </div>
</td>

          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="8" class="p-3 text-slate-500">Belum ada aset.</td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>

    <div class="mt-4"><?php echo e($rows->links()); ?></div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\bumdes-keuangan\resources\views/assets/index.blade.php ENDPATH**/ ?>