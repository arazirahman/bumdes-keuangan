<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
  <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
    <div class="rounded-2xl bg-white p-5 shadow">
      <div class="text-sm text-slate-500">Saldo Kas</div>
      <div class="mt-2 text-xl font-bold">Rp <?php echo e(number_format($saldo,0,',','.')); ?></div>
    </div>
    <div class="rounded-2xl bg-white p-5 shadow">
      <div class="text-sm text-slate-500">Pemasukan (<?php echo e($month); ?>)</div>
      <div class="mt-2 text-xl font-bold">Rp <?php echo e(number_format($income,0,',','.')); ?></div>
    </div>
    <div class="rounded-2xl bg-white p-5 shadow">
      <div class="text-sm text-slate-500">Pengeluaran (<?php echo e($month); ?>)</div>
      <div class="mt-2 text-xl font-bold">Rp <?php echo e(number_format($expense,0,',','.')); ?></div>
    </div>
    <div class="rounded-2xl bg-white p-5 shadow">
      <div class="text-sm text-slate-500">Laba/Rugi (<?php echo e($month); ?>)</div>
      <div class="mt-2 text-xl font-bold">Rp <?php echo e(number_format($profit,0,',','.')); ?></div>
    </div>
  </div>

  <div class="mt-6 rounded-2xl bg-white p-6 shadow">
    <form class="flex flex-wrap items-end gap-3">
      <div>
        <label class="mb-1 block text-sm font-semibold text-slate-700">Bulan</label>
        <input type="month" name="month" value="<?php echo e($month); ?>"
          class="rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm">
      </div>
      <button class="rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white">Tampilkan</button>
    </form>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\bumdes-keuangan\resources\views/dashboard.blade.php ENDPATH**/ ?>