<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
  <div class="rounded-2xl bg-white p-6 shadow">
    <form method="POST" action="<?php echo e(route('transactions.store')); ?>" enctype="multipart/form-data" class="grid gap-4 sm:grid-cols-2">
      <?php echo csrf_field(); ?>

      <div>
        <label class="mb-1 block text-sm font-semibold text-slate-700">Tanggal</label>
        <input type="date" name="trx_date" value="<?php echo e(old('trx_date', now()->toDateString())); ?>"
          class="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm">
        <?php $__errorArgs = ['trx_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div>
        <label class="mb-1 block text-sm font-semibold text-slate-700">Jenis</label>
        <select name="type" id="type"
          class="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm">
          <option value="income" <?php if(old('type')==='income'): echo 'selected'; endif; ?>>Pemasukan</option>
          <option value="expense" <?php if(old('type')==='expense'): echo 'selected'; endif; ?>>Pengeluaran</option>
        </select>
        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div>
        <label class="mb-1 block text-sm font-semibold text-slate-700">Unit Usaha</label>
        <select name="unit_usaha_id" class="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm">
          <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($u->id); ?>" <?php if((string)$u->id===old('unit_usaha_id')): echo 'selected'; endif; ?>><?php echo e($u->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['unit_usaha_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div>
        <label class="mb-1 block text-sm font-semibold text-slate-700">Kategori</label>
        <select name="category_id" id="category_id"
          class="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm">
        </select>
        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="sm:col-span-2">
        <label class="mb-1 block text-sm font-semibold text-slate-700">Keterangan</label>
        <input name="description" value="<?php echo e(old('description')); ?>"
          class="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm">
      </div>

      <div>
        <label class="mb-1 block text-sm font-semibold text-slate-700">Nominal (Rp)</label>
        <input name="amount" type="number" min="1" value="<?php echo e(old('amount')); ?>"
          class="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm">
        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div>
        <label class="mb-1 block text-sm font-semibold text-slate-700">Bukti (foto)</label>
        <input name="proof" type="file" accept="image/*"
          class="block w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm">
        <?php $__errorArgs = ['proof'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="sm:col-span-2 flex flex-wrap gap-2">
        <button class="rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:opacity-90">
          Simpan
        </button>
        <a href="<?php echo e(route('transactions.index')); ?>" class="rounded-xl border px-4 py-2 text-sm">
          Kembali
        </a>
      </div>
    </form>
  </div>

  <script>
    const incomeCats = <?php echo json_encode($incomeCats->map(fn($c)=>['id'=>$c->id, 'name'=>$c->name])->values(), 512) ?>;
    const expenseCats = <?php echo json_encode($expenseCats->map(fn($c)=>['id'=>$c->id, 'name'=>$c->name])->values(), 512) ?>;

    const typeEl = document.getElementById('type');
    const catEl  = document.getElementById('category_id');

    function renderCats(type){
      const list = (type === 'expense') ? expenseCats : incomeCats;
      catEl.innerHTML = '';
      list.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c.id;
        opt.textContent = c.name;
        catEl.appendChild(opt);
      });

      const oldCat = <?php echo json_encode(old('category_id'), 15, 512) ?>;
      if (oldCat) catEl.value = oldCat;
    }

    renderCats(typeEl.value || 'income');
    typeEl.addEventListener('change', () => renderCats(typeEl.value));
  </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\bumdes-keuangan\resources\views/transactions/create.blade.php ENDPATH**/ ?>